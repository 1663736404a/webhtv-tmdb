/*
 * Copyright (C) 2018 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package androidx.media3.extractor.text.pgs;

import androidx.media3.common.C;

/** Header information for a raw SUP segment. */
/* package */ final class PgsSupSegment {

  long ptsUs;
  int sectionType;
  int sectionLength;
  int nextSectionPosition;

  PgsSupSegment() {
    clear();
  }

  void set(long ptsUs, int sectionType, int sectionLength, int nextSectionPosition) {
    this.ptsUs = ptsUs;
    this.sectionType = sectionType;
    this.sectionLength = sectionLength;
    this.nextSectionPosition = nextSectionPosition;
  }

  void clear() {
    ptsUs = C.TIME_UNSET;
    sectionType = C.INDEX_UNSET;
    sectionLength = 0;
    nextSectionPosition = 0;
  }
}
